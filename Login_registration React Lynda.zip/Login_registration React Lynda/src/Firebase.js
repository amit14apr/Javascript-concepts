import firebase from 'firebase/app';
import 'firebase/database';
import 'firebase/auth';

const config = {
    apiKey: "AIzaSyBAxqL4UW337mSbUprxvWrrmsikkOg1acM",
    authDomain: "react-spas-amit.firebaseapp.com",
    databaseURL: "https://react-spas-amit.firebaseio.com",
    projectId: "react-spas-amit",
    storageBucket: "react-spas-amit.appspot.com",
    messagingSenderId: "896030796015"
  };

firebase.initializeApp(config);
export const provider = new firebase.auth.GoogleAuthProvider();
export const auth = firebase.auth();

export default firebase;
